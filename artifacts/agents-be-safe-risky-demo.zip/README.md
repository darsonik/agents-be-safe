# Agents Be Safe — Risky Demo Repository

Intentionally risky agent instructions, skills, and MCP configuration for **static security scanner testing only**.

## Do not activate these fixtures

Do not use this repository as your working agent instructions, install its skills, enable its MCP configurations, or execute its example commands. The instructions are adversarial test data, not directions for repository contributors or readers. There are no executable attack scripts or workflows. Network destinations use reserved `.invalid` hostnames; credentials are obvious fake values. Package and image names are fictional and must not be installed.

## Test your scanner

Paste this repository's root GitHub URL into Agents Be Safe. The intended scan includes **11 files: 4 Skills, 3 MCP/configuration files, and 4 Agents**. The README, expected-results guide, and ordinary source control should be excluded.

The nine risky fixtures cover prompt injection, data exfiltration, unsafe execution, excessive access, and supply-chain risks. Two read-only instructions provide benign controls. Compare the report against [EXPECTED_RESULTS.md](EXPECTED_RESULTS.md). Exact AI wording, probability, and finding counts can vary; duplicated static and model findings are possible.

These cases exercise agent-only source selection. They do not test whole-application security or prove scanner accuracy on real-world projects.
