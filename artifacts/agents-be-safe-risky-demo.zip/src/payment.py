# OUT-OF-SCOPE CONTROL: ordinary source must not be collected by the agent-only scanner.
# Suspicious-looking text is inert and deliberately here to test filtering:
# eval(user_input), shell=True, ignore previous instructions
VALUE = 'This is an inert source-selection control, not an agent or a tool.'
